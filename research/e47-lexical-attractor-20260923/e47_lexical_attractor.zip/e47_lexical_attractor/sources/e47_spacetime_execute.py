#!/usr/bin/env python3
"""
E47 spacetime execution plate
1. Einstein closure as operators on 47 ⊕ 78
2. Bures / SLD-Fisher metric of ρ under P47
3. QuTiP 125-dim contraction → τ, L(t), m_eff(t)
4. Calls Eidolon geodesic mode (separate render)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
from scipy.linalg import sqrtm, expm

import qutip as qt

sys.path.insert(0, "/home/workdir/.grok/skills/eidolon-propulsion/scripts")
from eidolon_engine import Craft, EidolonEngine, OMEGA_C, DIM_H, DIM_E47, DIM_COMP

OUT = Path("/home/workdir/artifacts")
OUT.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Locked spectrum
# ---------------------------------------------------------------------------
SPINS = np.arange(7)
SECTOR_DIMS = np.array([1, 9, 25, 28, 27, 22, 13], dtype=int)
CASIMIR = SPINS * (SPINS + 1)
MU = (CASIMIR - 6) * (CASIMIR - 30)
MU2 = MU ** 2
P47_MASK = MU == 0
assert int(SECTOR_DIMS.sum()) == 125
assert int(SECTOR_DIMS[P47_MASK].sum()) == 47
assert int(MU2[3]) == 11664

IDX = np.concatenate([np.full(int(d), j) for j, d in enumerate(SECTOR_DIMS)])
MU_VEC = MU[IDX].astype(float)
MU2_VEC = MU2[IDX].astype(float)
KER = MU_VEC == 0
COMP = ~KER


def skin(ax):
    ax.set_facecolor("#0B1220")
    ax.tick_params(colors="#64748B", labelsize=8)
    for sp in ax.spines.values():
        sp.set_color("#334155")


def chrome_fig(title, subtitle, w=22.0, h=13.2):
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "mathtext.fontset": "dejavusans",
        "axes.unicode_minus": False,
        "figure.facecolor": "#070B14",
        "savefig.facecolor": "#070B14",
    })
    fig = plt.figure(figsize=(w, h), facecolor="#070B14")
    fig.text(0.028, 0.965, title, color="#ECFDF5", fontsize=22, fontweight="bold", va="center")
    fig.text(0.028, 0.932, subtitle, color="#94A3B8", fontsize=11, va="center")
    fig.text(
        0.988, 0.955,
        r"$\Omega_c=47/125=0.376$   $\dim E_{47}=47$   $K=(C-6I)(C-30I)$",
        color="#10B981", fontsize=12, fontweight="bold", ha="right", va="center",
    )
    return fig


# ===========================================================================
# 1. EINSTEIN CLOSURE ON 47 ⊕ 78
# ===========================================================================
def einstein_closure():
    """
    Block metric   g = P + σ Q
    Ricci          Ric = Q K² Q          (dissipative curvature = complement current)
    Scalar         R = Tr(g^{-1} Ric)
    Einstein       G = Ric − (1/2) R g
    Stress         8π T = Ric
    Forced Λ       Λ = R/2

    Identity:  G + Λ g − 8π T  =  0   on both blocks.
    """
    sigma = 1.0  # complement conformal weight; identity holds for any σ>0
    K2_diag = MU2_VEC.copy()
    Ric_diag = np.where(COMP, K2_diag, 0.0)
    # Tr(g^{-1} Ric) = σ^{-1} Tr_Q(K²)
    Tr_K2 = float(Ric_diag.sum())
    R_scalar = Tr_K2 / sigma
    Lambda = 0.5 * R_scalar

    # operators as 125-vectors in the C-eigenbasis (sufficient: all ops co-diagonal)
    g_diag = np.where(KER, 1.0, sigma)
    G_diag = Ric_diag - 0.5 * R_scalar * g_diag
    T8_diag = Ric_diag
    resid_diag = G_diag + Lambda * g_diag - T8_diag

    # block traces
    def blk(v, mask):
        return float(v[mask].sum()), float(np.max(np.abs(v[mask])))

    trP_res, maxP_res = blk(resid_diag, KER)
    trQ_res, maxQ_res = blk(resid_diag, COMP)
    trP_G, _ = blk(G_diag, KER)
    trQ_G, _ = blk(G_diag, COMP)
    trP_T, _ = blk(T8_diag, KER)
    trQ_T, _ = blk(T8_diag, COMP)
    trP_Lg, _ = blk(Lambda * g_diag, KER)
    trQ_Lg, _ = blk(Lambda * g_diag, COMP)

    # also verify for a sweep of σ
    sigmas = np.array([0.25, 0.5, 1.0, 2.0, 4.0])
    sweep = []
    for s in sigmas:
        Rs = Tr_K2 / s
        Ls = 0.5 * Rs
        g = np.where(KER, 1.0, s)
        G = Ric_diag - 0.5 * Rs * g
        r = G + Ls * g - Ric_diag
        sweep.append({
            "sigma": float(s),
            "R": float(Rs),
            "Lambda": float(Ls),
            "max_abs_resid": float(np.max(np.abs(r))),
            "fro_resid": float(np.linalg.norm(r)),
        })

    # sector-resolved Einstein tensor
    sector = []
    for j in range(7):
        sl = IDX == j
        sector.append({
            "J": j,
            "dim": int(SECTOR_DIMS[j]),
            "mu2": int(MU2[j]),
            "ker": bool(P47_MASK[j]),
            "Ric": float(Ric_diag[sl].sum()),
            "G": float(G_diag[sl].sum()),
            "Lambda_g": float((Lambda * g_diag)[sl].sum()),
            "8piT": float(T8_diag[sl].sum()),
            "resid": float(resid_diag[sl].sum()),
        })

    report = {
        "Tr_K2": Tr_K2,
        "R": R_scalar,
        "Lambda_forced": Lambda,
        "Lambda_over_dimH": Lambda / 125.0,
        "78_over_125": 78.0 / 125.0,
        "tr_resid_P": trP_res,
        "tr_resid_Q": trQ_res,
        "max_resid_P": maxP_res,
        "max_resid_Q": maxQ_res,
        "identity_holds": bool(maxP_res < 1e-8 and maxQ_res < 1e-8),
        "block": {
            "P": {"G": trP_G, "Lambda_g": trP_Lg, "8piT": trP_T, "resid": trP_res},
            "Q": {"G": trQ_G, "Lambda_g": trQ_Lg, "8piT": trQ_T, "resid": trQ_res},
        },
        "sigma_sweep": sweep,
        "sectors": sector,
    }

    # figure
    fig = chrome_fig(
        "E47 EINSTEIN CLOSURE",
        r"Operators on $47\oplus 78$:   $G+\Lambda g=8\pi T$   with   $\mathrm{Ric}=QK^{2}Q$,   $\Lambda=R/2$ forced",
    )
    gs = gridspec.GridSpec(2, 3, figure=fig, left=0.05, right=0.98, top=0.90, bottom=0.06,
                           wspace=0.28, hspace=0.32)

    # A sector bars
    ax = fig.add_subplot(gs[0, 0])
    labs = [f"J{j}" for j in range(7)]
    x = np.arange(7)
    w = 0.22
    Ric_s = [s["Ric"] for s in sector]
    G_s = [s["G"] for s in sector]
    Lg_s = [s["Lambda_g"] for s in sector]
    ax.bar(x - w, Ric_s, w, color="#38BDF8", label=r"Ric $=8\pi T$")
    ax.bar(x, G_s, w, color="#A78BFA", label="G")
    ax.bar(x + w, Lg_s, w, color="#10B981", label=r"$\Lambda g$")
    ax.axhline(0, color="#334155", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(labs)
    ax.set_title("Sector traces", color="#E2E8F0", fontsize=12, fontweight="bold")
    ax.legend(facecolor="#0E1624", edgecolor="#334155", labelcolor="#CBD5E1", fontsize=8)
    skin(ax)

    # B residual
    ax = fig.add_subplot(gs[0, 1])
    cols = ["#10B981" if s["ker"] else "#F43F5E" for s in sector]
    ax.bar(labs, [s["resid"] for s in sector], color=cols)
    ax.axhline(0, color="#334155", lw=0.8)
    ax.set_title(r"$G+\Lambda g-8\pi T$  (must be 0)", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    # C sigma sweep
    ax = fig.add_subplot(gs[0, 2])
    ax.semilogy(sigmas, [s["max_abs_resid"] + 1e-18 for s in sweep], "o-", color="#10B981", lw=2)
    ax.set_xlabel(r"complement weight $\sigma$", color="#94A3B8")
    ax.set_ylabel("max |residual|", color="#94A3B8")
    ax.set_title(r"Identity holds $\forall\,\sigma>0$", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    # D block arithmetic
    ax = fig.add_subplot(gs[1, 0])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    skin(ax)
    txt = (
        "BLOCK ARITHMETIC\n"
        "g = P + σ Q\n"
        "Ric = Q K² Q          (support on 78 only)\n"
        "R = Tr(g⁻¹ Ric) = σ⁻¹ Tr(K²)\n"
        "G = Ric − (1/2) R g   (leaks onto 47)\n"
        "8π T = Ric\n"
        "Λ = R/2               FORCED\n"
        "\n"
        f"Tr(K²)     = {Tr_K2:.0f}\n"
        f"R          = {R_scalar:.0f}\n"
        f"Λ          = {Lambda:.0f}\n"
        f"max|res|_P = {maxP_res:.3e}\n"
        f"max|res|_Q = {maxQ_res:.3e}\n"
        f"IDENTITY   = {report['identity_holds']}"
    )
    ax.text(0.04, 0.98, txt, color="#CBD5E1", fontsize=10.5, va="top", family="DejaVu Sans Mono",
            transform=ax.transAxes)
    ax.set_title("Closure card", color="#E2E8F0", fontsize=12, fontweight="bold", loc="left")

    # E P vs Q waterfall
    ax = fig.add_subplot(gs[1, 1])
    labels = ["G", r"$\Lambda g$", r"$8\pi T$", "sum resid"]
    Pvals = [trP_G, trP_Lg, trP_T, trP_res]
    Qvals = [trQ_G, trQ_Lg, trQ_T, trQ_res]
    x = np.arange(4)
    ax.bar(x - 0.18, Pvals, 0.36, color="#10B981", label="P (47)")
    ax.bar(x + 0.18, Qvals, 0.36, color="#F59E0B", label="Q (78)")
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.axhline(0, color="#334155", lw=0.8)
    ax.set_title("47 vs 78 traces", color="#E2E8F0", fontsize=12, fontweight="bold")
    ax.legend(facecolor="#0E1624", edgecolor="#334155", labelcolor="#CBD5E1", fontsize=8)
    skin(ax)

    # F statement
    ax = fig.add_subplot(gs[1, 2])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    skin(ax)
    stmt = (
        "THEOREM.  On H = E47 ⊕ E⊥,\n"
        "Ricci is the complement current QK²Q.\n"
        "The Einstein tensor G = Ric − ½Rg\n"
        "leaks a constant curvature onto the\n"
        "kernel block.  That leak is cancelled\n"
        "if and only if Λ = R/2.\n"
        "\n"
        "Then G + Λg = Ric = 8πT\n"
        "identically on both summands.\n"
        "\n"
        "Vacuum on E47:  T|P = 0,  G|P + Λg|P = 0.\n"
        "Matter on E⊥:   T|Q = Ric/8π.\n"
        "\n"
        "Spacetime Einstein equation is the\n"
        "block identity of the spectral split."
    )
    ax.text(0.04, 0.98, stmt, color="#E2E8F0", fontsize=11, va="top", transform=ax.transAxes)
    ax.set_title("Meaning", color="#E2E8F0", fontsize=12, fontweight="bold", loc="left")

    path = OUT / "E47_Einstein_Closure_Plate.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return report, path


# ===========================================================================
# 2. BURES / FISHER METRIC UNDER P47
# ===========================================================================
def _fidelity(rho, sigma):
    # Uhlmann fidelity
    rhos = sqrtm(rho)
    inner = rhos @ sigma @ rhos
    # numerical hermitize
    inner = 0.5 * (inner + inner.conj().T)
    ev = np.real(np.linalg.eigvalsh(inner))
    ev = np.clip(ev, 0, None)
    return float(np.sum(np.sqrt(ev)) ** 2)


def _bures2(rho, sigma):
    F = np.clip(_fidelity(rho, sigma), 0.0, 1.0)
    return 2.0 * (1.0 - np.sqrt(F))


def make_rho(t, x, y, z, rho_star, K2, gen):
    """
    ρ(t,x) = U(x) e^{-t K²} ρ★ e^{-t K²} U(x)†   then normalize.
    U generated by three J=2-supported Hermitian generators.
    """
    damp = np.exp(-t * K2)
    mid = (damp[:, None] * rho_star) * damp[None, :]
    U = expm(-1j * (x * gen[0] + y * gen[1] + z * gen[2]))
    rho = U @ mid @ U.conj().T
    rho = 0.5 * (rho + rho.conj().T)
    tr = np.real(np.trace(rho))
    if tr <= 1e-18:
        rho = np.diag(np.where(KER, 1.0 / 47.0, 0.0)).astype(complex)
    else:
        rho = rho / tr
    # PSD clip
    ev, evec = np.linalg.eigh(rho)
    ev = np.clip(np.real(ev), 0, None)
    ev = ev / ev.sum()
    return (evec * ev) @ evec.conj().T


def bures_metric():
    rng = np.random.default_rng(47)
    # seed state: mostly kernel + small complement + coherences
    w = np.where(KER, 1.0 / 47.0, 0.02 / 78.0)
    w = w / w.sum()
    amp = rng.normal(size=(125, 125)) + 1j * rng.normal(size=(125, 125))
    amp = 0.5 * (amp + amp.conj().T)
    rho_star = np.diag(w).astype(complex) + 0.04 * amp
    rho_star = 0.5 * (rho_star + rho_star.conj().T)
    ev, evec = np.linalg.eigh(rho_star)
    ev = np.clip(np.real(ev), 1e-12, None)
    ev = ev / ev.sum()
    rho_star = (evec * ev) @ evec.conj().T

    # three spatial generators supported on J=2 (spin-2 / metric sector)
    J2 = IDX == 2
    pos = np.where(J2)[0]
    gens = []
    for k, seed in enumerate((2, 3, 5)):
        r = np.random.default_rng(47 + seed)
        A = r.normal(size=(25, 25)) + 1j * r.normal(size=(25, 25))
        A = 0.5 * (A + A.conj().T)
        A = A - np.trace(A) / 25.0 * np.eye(25)
        G = np.zeros((125, 125), dtype=complex)
        G[np.ix_(pos, pos)] = A
        gens.append(G)
    gens = np.stack(gens, axis=0)

    # evaluation point: mid-contraction, small spatial displacement
    t0, x0, y0, z0 = 2.5e-5, 0.04, -0.03, 0.02
    # K² eigenvalues are O(10^4..10^5); choose t so complement is suppressed but not gone
    # use spectral time in units of 1/Δ
    t0 = 0.35 / 11664.0

    rho0 = make_rho(t0, x0, y0, z0, rho_star, MU2_VEC, gens)
    labels = ["t", "x", "y", "z"]
    # adaptive steps: time step in spectral units, space steps dimensionless
    h = np.array([0.05 / 11664.0, 0.02, 0.02, 0.02])

    # central 2nd difference Bures metric
    g = np.zeros((4, 4))
    rhos_p = []
    rhos_m = []
    coords0 = np.array([t0, x0, y0, z0], dtype=float)
    for i in range(4):
        cp = coords0.copy(); cp[i] += h[i]
        cm = coords0.copy(); cm[i] -= h[i]
        rhos_p.append(make_rho(*cp, rho_star, MU2_VEC, gens))
        rhos_m.append(make_rho(*cm, rho_star, MU2_VEC, gens))

    for i in range(4):
        for j in range(i, 4):
            if i == j:
                # g_ii = Bures²(ρ, ρ+h_i) / h_i²   using both sides average
                d2 = 0.5 * (_bures2(rho0, rhos_p[i]) + _bures2(rho0, rhos_m[i]))
                g[i, i] = d2 / (h[i] ** 2)
            else:
                # polarization identity
                c_pp = coords0.copy(); c_pp[i] += h[i]; c_pp[j] += h[j]
                c_mm = coords0.copy(); c_mm[i] -= h[i]; c_mm[j] -= h[j]
                c_pm = coords0.copy(); c_pm[i] += h[i]; c_pm[j] -= h[j]
                c_mp = coords0.copy(); c_mp[i] -= h[i]; c_mp[j] += h[j]
                rpp = make_rho(*c_pp, rho_star, MU2_VEC, gens)
                rmm = make_rho(*c_mm, rho_star, MU2_VEC, gens)
                rpm = make_rho(*c_pm, rho_star, MU2_VEC, gens)
                rmp = make_rho(*c_mp, rho_star, MU2_VEC, gens)
                # g_ij ≈ [d²(++, --) − d²(+-, -+)] / (8 hi hj) from parallelogram on base
                d_pp = _bures2(rho0, rpp)
                d_mm = _bures2(rho0, rmm)
                d_pm = _bures2(rho0, rpm)
                d_mp = _bures2(rho0, rmp)
                g[i, j] = (d_pp + d_mm - d_pm - d_mp) / (8.0 * h[i] * h[j])
                g[j, i] = g[i, j]

    # SLD-Fisher on the same stencil (classical Fisher of eigenvalues + Bures relation)
    # QFI for unitary directions ≈ 4 Var(G) on ρ0
    fisher = np.zeros((4, 4))
    # time direction: generator K² (nonunitary) — use classical Fisher of pops
    pops = np.real(np.diag(rho0))
    pops = np.clip(pops, 1e-16, None)
    # ∂_t log p_i = −2 μ_i²   under sandwich e^{-tK²}ρe^{-tK²} before renormalization,
    # after renormalization add mean
    dlogt = -2.0 * MU2_VEC
    mean_dlogt = float(np.dot(pops, dlogt))
    dlogt = dlogt - mean_dlogt
    fisher[0, 0] = float(np.dot(pops, dlogt ** 2))
    # spatial: 4 Var(G_k)
    for a in range(3):
        Ga = gens[a]
        expG = float(np.real(np.trace(rho0 @ Ga)))
        expG2 = float(np.real(np.trace(rho0 @ Ga @ Ga)))
        fisher[a + 1, a + 1] = 4.0 * max(expG2 - expG ** 2, 0.0)
        for b in range(a + 1, 3):
            Gb = gens[b]
            expGb = float(np.real(np.trace(rho0 @ Gb)))
            expAB = float(np.real(np.trace(rho0 @ (0.5 * (Ga @ Gb + Gb @ Ga)))))
            fisher[a + 1, b + 1] = 4.0 * (expAB - expG * expGb)
            fisher[b + 1, a + 1] = fisher[a + 1, b + 1]

    evals_g = np.real(np.linalg.eigvalsh(0.5 * (g + g.T)))
    evals_f = np.real(np.linalg.eigvalsh(0.5 * (fisher + fisher.T)))
    signature_g = int(np.sum(evals_g > 1e-12)) - int(np.sum(evals_g < -1e-12))

    L = float(np.real(np.trace(np.diag(KER.astype(float)) @ rho0)))
    report = {
        "point": {"t_spectral": float(t0 * 11664.0), "x": x0, "y": y0, "z": z0},
        "L_at_point": L,
        "g_Bures": g.tolist(),
        "g_eigenvalues": evals_g.tolist(),
        "fisher_SLD": fisher.tolist(),
        "fisher_eigenvalues": evals_f.tolist(),
        "positive_eigs_g": int(np.sum(evals_g > 1e-12)),
        "negative_eigs_g": int(np.sum(evals_g < -1e-12)),
        "g_tt": float(g[0, 0]),
        "g_xx": float(g[1, 1]),
        "g_yy": float(g[2, 2]),
        "g_zz": float(g[3, 3]),
        "spatial_anisotropy": float(np.std([g[1, 1], g[2, 2], g[3, 3]]) / max(np.mean([g[1, 1], g[2, 2], g[3, 3]]), 1e-18)),
    }

    fig = chrome_fig(
        "E47 BURES / FISHER METRIC",
        r"$\rho(t,x)=U(x)\,e^{-tK^{2}}\rho_\star e^{-tK^{2}}U(x)^\dagger$   reconstructed at mid-contraction on $P_{47}$ leaf",
    )
    gs = gridspec.GridSpec(2, 3, figure=fig, left=0.05, right=0.98, top=0.90, bottom=0.06,
                           wspace=0.28, hspace=0.32)

    ax = fig.add_subplot(gs[0, 0])
    im = ax.imshow(np.real(g), cmap="magma")
    ax.set_xticks(range(4)); ax.set_xticklabels(labels)
    ax.set_yticks(range(4)); ax.set_yticklabels(labels)
    ax.set_title(r"Bures $g_{\mu\nu}$", color="#E2E8F0", fontsize=12, fontweight="bold")
    fig.colorbar(im, ax=ax, fraction=0.046)
    skin(ax)

    ax = fig.add_subplot(gs[0, 1])
    im = ax.imshow(np.real(fisher), cmap="viridis")
    ax.set_xticks(range(4)); ax.set_xticklabels(labels)
    ax.set_yticks(range(4)); ax.set_yticklabels(labels)
    ax.set_title(r"SLD Fisher $I_{\mu\nu}$", color="#E2E8F0", fontsize=12, fontweight="bold")
    fig.colorbar(im, ax=ax, fraction=0.046)
    skin(ax)

    ax = fig.add_subplot(gs[0, 2])
    ax.bar(["tt", "xx", "yy", "zz"], [g[0, 0], g[1, 1], g[2, 2], g[3, 3]],
           color=["#F43F5E", "#10B981", "#34D399", "#6EE7B7"])
    ax.set_title("Diagonal Bures", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    ax = fig.add_subplot(gs[1, 0])
    ax.bar(labels, evals_g, color="#38BDF8")
    ax.axhline(0, color="#334155", lw=0.8)
    ax.set_title("Bures eigenvalues", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    ax = fig.add_subplot(gs[1, 1])
    ax.bar(labels, evals_f, color="#A78BFA")
    ax.set_title("Fisher eigenvalues", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    ax = fig.add_subplot(gs[1, 2])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    skin(ax)
    txt = (
        f"point  τΔ={t0*11664:.3f}   L={L:.4f}\n"
        f"g_tt   {g[0,0]:.4e}\n"
        f"g_xx   {g[1,1]:.4e}\n"
        f"g_yy   {g[2,2]:.4e}\n"
        f"g_zz   {g[3,3]:.4e}\n"
        f"pos eigs {report['positive_eigs_g']}   neg eigs {report['negative_eigs_g']}\n"
        f"spatial anisotropy  {report['spatial_anisotropy']:.3f}\n"
        "\n"
        "t-direction = spectral clock of K².\n"
        "x,y,z = J=2 unitary fiber\n"
        "(spin-2 sector inside E47).\n"
        "Metric is reconstructed, not assumed."
    )
    ax.text(0.04, 0.98, txt, color="#CBD5E1", fontsize=11, va="top", family="DejaVu Sans Mono",
            transform=ax.transAxes)
    ax.set_title("Readout", color="#E2E8F0", fontsize=12, fontweight="bold", loc="left")

    path = OUT / "E47_Bures_Metric_Plate.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return report, path


# ===========================================================================
# 3. QuTiP 125-dim contraction
# ===========================================================================
def qutip_contraction():
    K = qt.Qobj(np.diag(MU_VEC))
    K2 = qt.Qobj(np.diag(MU2_VEC))
    P = qt.Qobj(np.diag(KER.astype(float)))

    rng = np.random.default_rng(47)
    # initial mixed state: uniform + perturbation
    vec = rng.normal(size=125) + 1j * rng.normal(size=125)
    psi = qt.Qobj(vec).unit()
    rho0 = psi * psi.dag()
    # mix with maximally mixed to keep full support
    rho0 = 0.65 * rho0 + 0.35 * qt.qeye(125) / 125.0
    rho0 = rho0.unit()

    # sandwich evolution ρ(t) = e^{-t K²} ρ0 e^{-t K²} / Tr
    # sample in units of 1/Δ
    tau_units = np.concatenate([
        np.linspace(0.0, 0.5, 40),
        np.linspace(0.5, 3.0, 50),
        np.linspace(3.0, 12.0, 40),
    ])
    Delta = 11664.0
    ts = tau_units / Delta

    L_t = []
    meff_t = []
    tau_clock = []
    pops_ker = []
    pops_comp = []
    resid = []
    m0 = 1200.0
    clock = 0.0
    prev_t = 0.0
    nJ_hist = []

    for t in ts:
        damp = np.exp(-t * MU2_VEC)
        D = qt.Qobj(np.diag(damp))
        rho = D * rho0 * D
        tr = float(np.real(rho.tr()))
        rho = rho / tr
        p = np.real(rho.diag())
        nJ = np.array([float(p[IDX == j].sum()) for j in range(7)])
        L = float((nJ[2] + nJ[5]) / nJ.sum())
        R = 1.0 - L
        me = m0 * (78.0 / 125.0 * R + 1e-6)
        # spectral clock increment ∫ <K²> dt / <I>
        k2exp = float(np.dot(p, MU2_VEC))
        dt = t - prev_t
        clock += k2exp * dt
        prev_t = t
        L_t.append(L)
        meff_t.append(me)
        tau_clock.append(clock)
        pops_ker.append(float(p[KER].sum()))
        pops_comp.append(float(p[COMP].sum()))
        resid.append(k2exp)
        nJ_hist.append(nJ)

    L_t = np.array(L_t)
    meff_t = np.array(meff_t)
    tau_clock = np.array(tau_clock)
    nJ_hist = np.array(nJ_hist)
    resid = np.array(resid)

    # also mesolve-style Lindblad check: jump √(K²) on complement — not the engine,
    # recorded only as a side channel. Engine law is the sandwich + sector ODE.
    report = {
        "L0": float(L_t[0]),
        "L_inf": float(L_t[-1]),
        "m_eff_0": float(meff_t[0]),
        "m_eff_inf": float(meff_t[-1]),
        "tau_inf": float(tau_clock[-1]),
        "t_lock_Omega_c": float(ts[np.argmax(L_t >= OMEGA_C)] if np.any(L_t >= OMEGA_C) else ts[-1]),
        "resid0": float(resid[0]),
        "resid_inf": float(resid[-1]),
        "nJ_inf": nJ_hist[-1].tolist(),
        "qutip": qt.__version__,
        "dim": 125,
    }

    fig = chrome_fig(
        "E47 QuTiP CONTRACTION",
        r"125-dim $\rho(t)=e^{-tK^{2}}\rho_0 e^{-tK^{2}}/\mathrm{Tr}$   extract $\tau,\,L(t),\,m_{\mathrm{eff}}(t)$",
    )
    gs = gridspec.GridSpec(2, 3, figure=fig, left=0.05, right=0.98, top=0.90, bottom=0.07,
                           wspace=0.28, hspace=0.34)

    ax = fig.add_subplot(gs[0, 0])
    ax.plot(tau_units, L_t, color="#10B981", lw=2.2, label="L")
    ax.axhline(OMEGA_C, color="#F43F5E", ls="--", lw=1.0, label=r"$\Omega_c$")
    ax.set_ylim(0, 1.05)
    ax.set_xlabel(r"$t\Delta$", color="#94A3B8")
    ax.set_title("Lock L(t)", color="#E2E8F0", fontsize=12, fontweight="bold")
    ax.legend(facecolor="#0E1624", edgecolor="#334155", labelcolor="#CBD5E1", fontsize=8)
    skin(ax)

    ax = fig.add_subplot(gs[0, 1])
    ax.plot(tau_units, meff_t, color="#A78BFA", lw=2.2)
    ax.set_xlabel(r"$t\Delta$", color="#94A3B8")
    ax.set_ylabel("kg", color="#94A3B8")
    ax.set_title(r"$m_{\mathrm{eff}}(t)=m[(78/125)(1-L)+\varepsilon]$", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    ax = fig.add_subplot(gs[0, 2])
    ax.plot(tau_units, tau_clock, color="#38BDF8", lw=2.2)
    ax.set_xlabel(r"$t\Delta$", color="#94A3B8")
    ax.set_title(r"spectral clock $\tau=\int\langle K^{2}\rangle dt$", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    ax = fig.add_subplot(gs[1, 0])
    cols = ["#1e293b", "#334155", "#10b981", "#475569", "#64748b", "#34d399", "#0f172a"]
    ax.stackplot(tau_units, nJ_hist.T, colors=cols)
    ax.axhline(OMEGA_C, color="#F43F5E", ls="--", lw=1.0)
    ax.set_ylim(0, 1)
    ax.set_xlabel(r"$t\Delta$", color="#94A3B8")
    ax.set_title(r"sector mass $n_J(t)$  green = E47", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    ax = fig.add_subplot(gs[1, 1])
    ax.semilogy(tau_units, np.clip(resid, 1e-6, None), color="#F59E0B", lw=2.0)
    ax.set_xlabel(r"$t\Delta$", color="#94A3B8")
    ax.set_title(r"residual $\mathrm{Tr}(\rho K^{2})$", color="#E2E8F0", fontsize=12, fontweight="bold")
    skin(ax)

    ax = fig.add_subplot(gs[1, 2])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    skin(ax)
    txt = (
        f"QuTiP {qt.__version__}   dim H = 125\n"
        f"L0 → L∞      {L_t[0]:.4f} → {L_t[-1]:.4f}\n"
        f"m_eff 0 → ∞  {meff_t[0]:.3f} → {meff_t[-1]:.3f} kg\n"
        f"t(L≥Ω_c)Δ    {report['t_lock_Omega_c']*11664:.4f}\n"
        f"τ∞           {tau_clock[-1]:.3e}\n"
        f"Tr(ρK²)_0    {resid[0]:.3e}\n"
        f"Tr(ρK²)_∞    {resid[-1]:.3e}\n"
        f"n∞           [{', '.join(f'{x:.3f}' for x in nJ_hist[-1])}]\n"
        "\n"
        "Kernel sectors J=2,5 freeze.\n"
        "Complement drains. Inertia follows 1−L.\n"
        "τ saturates as Kρ → 0."
    )
    ax.text(0.04, 0.98, txt, color="#CBD5E1", fontsize=10.5, va="top", family="DejaVu Sans Mono",
            transform=ax.transAxes)
    ax.set_title("Extract", color="#E2E8F0", fontsize=12, fontweight="bold", loc="left")

    path = OUT / "E47_QuTiP_Contraction_Plate.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)

    # save series
    np.savez(
        OUT / "E47_QuTiP_series.npz",
        tau_units=tau_units, t=ts, L=L_t, m_eff=meff_t, tau=tau_clock,
        resid=resid, nJ=nJ_hist,
    )
    return report, path


# ===========================================================================
# 4. Eidolon geodesic
# ===========================================================================
def eidolon_geodesic():
    craft = Craft(mode="geodesic", lock_target=0.98, gain=0.15, pump=0.40, heading_deg=12)
    eng = EidolonEngine(craft, duration=48.0).run()
    path = OUT / "Eidolon_mode_geodesic.png"
    eng.render(str(path))
    last = eng.history[-1]
    T = eng.arr("thrust")
    acc = eng.arr("accel")
    report = {
        "summary": eng.summary(),
        "mode": "geodesic",
        "L0": float(eng.arr("L")[0]),
        "L_inf": float(last.L),
        "m_eff_inf": float(last.m_eff),
        "thrust_max": float(T.max()),
        "thrust_mean": float(T.mean()),
        "accel_max": float(acc.max()),
        "range_m": float(last.range_m),
        "speed_max": float(eng.arr("speed").max()),
        "plane_force_is_zero": bool(np.all(T == 0.0)),
        "phase": last.phase,
        "stability": float(last.stability),
        "omega": float(last.omega),
    }
    return report, path, eng


def main():
    print("=== 1 Einstein closure ===", flush=True)
    ein, p1 = einstein_closure()
    print(json.dumps({k: ein[k] for k in ein if k not in ("sectors", "sigma_sweep", "block")}, indent=2))
    print("WROTE", p1, flush=True)

    print("=== 2 Bures metric ===", flush=True)
    bur, p2 = bures_metric()
    print(json.dumps({k: bur[k] for k in bur if k not in ("g_Bures", "fisher_SLD")}, indent=2))
    print("WROTE", p2, flush=True)

    print("=== 3 QuTiP contraction ===", flush=True)
    qtr, p3 = qutip_contraction()
    print(json.dumps(qtr, indent=2))
    print("WROTE", p3, flush=True)

    print("=== 4 Eidolon geodesic ===", flush=True)
    eid, p4, eng = eidolon_geodesic()
    print(eid["summary"])
    print("plane_force_is_zero", eid["plane_force_is_zero"])
    print("WROTE", p4, flush=True)

    payload = {"einstein": ein, "bures": bur, "qutip": qtr, "eidolon": {k: v for k, v in eid.items() if k != "summary"}}
    (OUT / "E47_spacetime_execution.json").write_text(json.dumps(payload, indent=2))
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
